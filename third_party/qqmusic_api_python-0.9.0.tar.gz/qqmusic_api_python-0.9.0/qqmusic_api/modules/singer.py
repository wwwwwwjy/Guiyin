"""歌手相关 API."""

from enum import Enum, IntEnum
from typing import Any, Literal, TypedDict, cast, overload

from ..core import PaginatedCgiRequest, Platform
from ..core.endpoint import CgiRequestData, cgi_endpoint
from ..core.pagination import (
    MultiFieldContinuationStrategy,
    OffsetStrategy,
    PageStrategy,
)
from ..models.base import Song
from ..models.singer import (
    AlbumBrief,
    HomepageHeaderResponse,
    HomepageTabDetailResponse,
    SimilarSingerResponse,
    SingerAlbumListResponse,
    SingerBrief,
    SingerDetailResponse,
    SingerIndexPageResponse,
    SingerMvListResponse,
    SingerMvTagResponse,
    SingerSongListResponse,
    SingerTypeListResponse,
    VideoBrief,
)
from ._base import ApiModule


class AreaType(IntEnum):
    """地区类型枚举."""

    ALL = -100
    CHINA = 200
    TAIWAN = 2
    AMERICA = 5
    JAPAN = 4
    KOREA = 3


class GenreType(IntEnum):
    """风格类型枚举."""

    ALL = -100
    POP = 7
    RAP = 3
    CHINESE_STYLE = 19
    ROCK = 4
    ELECTRONIC = 2
    FOLK = 8
    R_AND_B = 11
    ETHNIC = 37
    LIGHT_MUSIC = 93
    JAZZ = 14
    CLASSICAL = 33
    COUNTRY = 13
    BLUES = 10


class SexType(IntEnum):
    """性别类型枚举."""

    ALL = -100
    MALE = 0
    FEMALE = 1
    GROUP = 2


class TabType(Enum):
    """歌手主页 Tab 枚举."""

    WIKI = ("wiki", "IntroductionTab")
    ALBUM = ("album", "AlbumTab")
    COMPOSER = ("song_composing", "SongTab")
    LYRICIST = ("song_lyric", "SongTab")
    PRODUCER = ("producer", "SongTab")
    ARRANGER = ("arranger", "SongTab")
    MUSICIAN = ("musician", "SongTab")
    SONG = ("song_sing", "SongTab")
    VIDEO = ("video", "VideoTab")

    def __init__(self, tab_id: str, tab_name: str) -> None:
        """初始化歌手主页 Tab 类型.

        Args:
            tab_id: Tab 标识符.
            tab_name: Tab 名称.
        """
        self.tab_id = tab_id
        self.tab_name = tab_name


class OrderType(IntEnum):
    """歌手主页条目排序类型.

    + LATEST: 最新 / 按时间排序 (0)
    + HOT: 最热 / 按热度排序 (1)
    """

    LATEST = 0
    HOT = 1


class AlbumFilterType(IntEnum):
    """专辑分类筛选类型.

    + STUDIO: 录音室专辑 (0)
    + LIVE: 现场专辑 (1)
    + EP: EP (11)
    """

    STUDIO = 0
    LIVE = 1
    EP = 11


class IndexType(IntEnum):
    """首字母索引枚举."""

    A = 1
    B = 2
    C = 3
    D = 4
    E = 5
    F = 6
    G = 7
    H = 8
    I = 9
    J = 10
    K = 11
    L = 12
    M = 13
    N = 14
    O = 15
    P = 16
    Q = 17
    R = 18
    S = 19
    T = 20
    U = 21
    V = 22
    W = 23
    X = 24
    Y = 25
    Z = 26
    ALL = -100
    HASH = 27


class AlbumExtension(TypedDict):
    """专辑 Tab 扩展参数.

    Attributes:
        IsNeedFilterType: 是否下发分类筛选列表.
        FilterType: 分类筛选值.
    """

    IsNeedFilterType: int
    FilterType: int


class VideoExtension(TypedDict):
    """视频 Tab 扩展参数.

    Attributes:
        TagID: 视频标签筛选值.
        IsNeedTagList: 是否下发标签列表.
    """

    TagID: int
    IsNeedTagList: int


class SingerApi(ApiModule):
    """歌手相关 API."""

    @cgi_endpoint(
        key="singer.get_singer_list",
        module="music.musichallSinger.SingerList",
        method="GetSingerList",
        response_model=SingerTypeListResponse,
    )
    def get_singer_list(
        self,
        area: int | AreaType = AreaType.ALL,
        sex: int | SexType = SexType.ALL,
        genre: int | GenreType = GenreType.ALL,
    ) -> CgiRequestData:
        """获取歌手列表原始数据.

        Args:
            area: 地区类型.
            sex: 性别类型.
            genre: 风格类型.
        """
        return CgiRequestData(
            param={
                "hastag": 0,
                "area": int(AreaType(area)),
                "sex": int(SexType(sex)),
                "genre": int(GenreType(genre)),
            },
        )

    @cgi_endpoint(
        key="singer.get_singer_list_index",
        module="music.musichallSinger.SingerList",
        method="GetSingerListIndex",
        response_model=SingerIndexPageResponse,
        item_type=SingerBrief,
    )
    def get_singer_list_index(
        self,
        area: int | AreaType = AreaType.ALL,
        sex: int | SexType = SexType.ALL,
        genre: int | GenreType = GenreType.ALL,
        index: int | IndexType = IndexType.ALL,
        page: int = 1,
        num: int = 80,
    ) -> CgiRequestData:
        """获取按索引分页的歌手列表原始数据.

        Args:
            area: 地区类型.
            sex: 性别类型.
            genre: 风格类型.
            index: 首字母索引.
            page: 页码.
            num: 每页返回数量.
        """
        return CgiRequestData(
            param={
                "area": int(AreaType(area)),
                "sex": int(SexType(sex)),
                "genre": int(GenreType(genre)),
                "index": int(IndexType(index)),
                "sin": (page - 1) * num,
                "cur_page": page,
            },
            pager_strategy=MultiFieldContinuationStrategy[SingerIndexPageResponse](
                lambda params, response: (
                    None
                    if not response.singerlist or params["sin"] + len(response.singerlist) >= (response.total or 0)
                    else {
                        **cast("dict[str, int]", params),
                        "sin": cast("dict[str, int]", params)["sin"] + len(response.singerlist),
                        "cur_page": cast("dict[str, int]", params)["cur_page"] + 1,
                    }
                ),
                context_name="singer_list_index",
            ),
            items_extractor=lambda r: r.singerlist,
        )

    @cgi_endpoint(
        key="singer.get_info",
        module="music.UnifiedHomepage.UnifiedHomepageSrv",
        method="GetHomepageHeader",
        platform=Platform.ANDROID,
        response_model=HomepageHeaderResponse,
    )
    def get_info(self, mid: str) -> CgiRequestData:
        """获取歌手主页基本信息.

        固定使用 Android 平台.

        Args:
            mid: 歌手 MID.
        """
        return CgiRequestData(
            param={"SingerMid": mid},
        )

    @overload
    def get_tab_detail(
        self,
        mid: str,
        tab_type: Literal[TabType.VIDEO],
        page: int = 1,
        num: int = 10,
        order: OrderType | int = OrderType.LATEST,
        extension: VideoExtension | None = None,
    ) -> PaginatedCgiRequest[HomepageTabDetailResponse]: ...

    @overload
    def get_tab_detail(
        self,
        mid: str,
        tab_type: Literal[TabType.ALBUM],
        page: int = 1,
        num: int = 10,
        order: OrderType | int = OrderType.LATEST,
        extension: AlbumExtension | None = None,
    ) -> PaginatedCgiRequest[HomepageTabDetailResponse]: ...

    @overload
    def get_tab_detail(
        self,
        mid: str,
        tab_type: TabType,
        page: int = 1,
        num: int = 10,
        order: OrderType | int = OrderType.LATEST,
    ) -> PaginatedCgiRequest[HomepageTabDetailResponse]: ...

    @cgi_endpoint(
        key="singer.get_tab_detail",
        module="music.UnifiedHomepage.UnifiedHomepageSrv",
        method="GetHomepageTabDetail",
        response_model=HomepageTabDetailResponse,
        pager=True,
    )
    def get_tab_detail(
        self,
        mid: str,
        tab_type: TabType,
        page: int = 1,
        num: int = 10,
        order: OrderType | int = OrderType.LATEST,
        extension: VideoExtension | AlbumExtension | None = None,
    ) -> CgiRequestData:
        """获取歌手主页特定 Tab 的详情原始数据.

        Args:
            mid: 歌手 MID.
            tab_type: Tab 类型.
            page: 页码.
            num: 返回数量.
            order: 排序方式 (最新 / 最热).
            extension: Tab 请求扩展参数.
        """
        param: dict[str, Any] = {
            "SingerMid": mid,
            "IsQueryTabDetail": 1,
            "TabID": tab_type.tab_id,
            "PageNum": page - 1,
            "PageSize": num,
            "Order": int(order),
        }
        if extension:
            param[tab_type.value[1].replace("Tab", "") + "Extension"] = extension
        return CgiRequestData(
            param=param,
            pager_strategy=PageStrategy[HomepageTabDetailResponse](
                page_key="PageNum",
                page_size=num,
                start_page=page - 1,
                has_more_extractor=lambda response: bool(response.has_more),
            ),
        )

    @cgi_endpoint(
        key="singer.get_desc",
        module="music.musichallSinger.SingerInfoInter",
        method="GetSingerDetail",
        response_model=SingerDetailResponse,
    )
    def get_desc(
        self,
        mids: list[str],
        *,
        ex_singer: bool = True,
        wiki_singer: bool = True,
        group_singer: bool = True,
        pic: bool = True,
        photos: bool = True,
    ) -> CgiRequestData:
        """获取歌手列表的描述信息.

        Args:
            mids: 歌手 MID 列表.
            ex_singer: 是否返回扩展描述信息.
            wiki_singer: 是否返回百科 XML 数据.
            group_singer: 是否返回组合成员信息.
            pic: 是否返回头像/立绘图片 URL.
            photos: 是否返回相册大图列表.
        """
        return CgiRequestData(
            param={
                "singer_mids": mids,
                "group_singer": group_singer,
                "wiki_singer": wiki_singer,
                "ex_singer": ex_singer,
                "pic": pic,
                "photos": photos,
            },
        )

    @cgi_endpoint(
        key="singer.get_similar",
        module="music.SimilarSingerSvr",
        method="GetSimilarSingerList",
        response_model=SimilarSingerResponse,
    )
    def get_similar(self, mid: str, number: int = 10) -> CgiRequestData:
        """获取相似歌手列表.

        Args:
            mid: 歌手 MID.
            number: 返回相似歌手的数量.
        """
        return CgiRequestData(
            param={"singerMid": mid, "number": number},
        )

    @cgi_endpoint(
        key="singer.get_songs_list",
        module="musichall.song_list_server",
        method="GetSingerSongList",
        response_model=SingerSongListResponse,
        item_type=Song,
    )
    def get_songs_list(
        self,
        mid: str,
        num: int = 10,
        page: int = 1,
        order: OrderType | int = OrderType.HOT,
    ) -> CgiRequestData:
        """获取歌手的歌曲列表.

        Args:
            mid: 歌手 MID.
            num: 返回歌曲数量.
            page: 分页页码.
            order: 排序方式.
        """
        return CgiRequestData(
            param={"singerMid": mid, "order": int(order), "number": num, "begin": (page - 1) * num},
            pager_strategy=OffsetStrategy[SingerSongListResponse](
                offset_key="begin",
                page_size_key="number",
                total_extractor=lambda r: r.total_num,
                count_extractor=lambda r: len(r.song_list),
            ),
            items_extractor=lambda response: response.song_list,
        )

    @cgi_endpoint(
        key="singer.get_album_list",
        module="music.musichallAlbum.AlbumListServer",
        method="GetAlbumList",
        response_model=SingerAlbumListResponse,
        item_type=AlbumBrief,
    )
    def get_album_list(
        self,
        mid: str,
        num: int = 10,
        page: int = 1,
        order: OrderType | int = OrderType.HOT,
        filter_type: AlbumFilterType | int | None = None,
    ) -> CgiRequestData:
        """获取歌手的专辑列表.

        Args:
            mid: 歌手 MID.
            num: 返回专辑数量.
            page: 分页页码.
            order: 排序方式.
            filter_type: 专辑分类筛选 (types, 值域见 AlbumFilterType).
        """
        param: dict[str, Any] = {"singerMid": mid, "order": int(order), "number": num, "begin": (page - 1) * num}
        if filter_type is not None:
            param["types"] = [int(filter_type)]
        return CgiRequestData(
            param=param,
            pager_strategy=OffsetStrategy[SingerAlbumListResponse](
                offset_key="begin",
                page_size_key="number",
                total_extractor=lambda r: r.total,
                count_extractor=lambda r: len(r.album_list),
            ),
            items_extractor=lambda r: r.album_list,
        )

    @cgi_endpoint(
        key="singer.get_mv_tag",
        module="MvService.MvInfoProServer",
        method="GetSingerMvTag",
        response_model=SingerMvTagResponse,
    )
    def get_mv_tag(self, mid: str) -> CgiRequestData:
        """获取歌手 MV 分类标签列表.

        Args:
            mid: 歌手 MID.
        """
        return CgiRequestData(param={"singermid": mid})

    @cgi_endpoint(
        key="singer.get_mv_list",
        module="MvService.MvInfoProServer",
        method="GetSingerMvList",
        response_model=SingerMvListResponse,
        item_type=VideoBrief,
    )
    def get_mv_list(
        self,
        mid: str,
        num: int = 10,
        page: int = 1,
        order: OrderType | int = OrderType.HOT,
        tag_id: int | None = None,
    ) -> CgiRequestData:
        """获取歌手 MV 列表数据.

        Args:
            mid: 歌手 MID.
            num: 返回数量.
            page: 分页页码.
            order: 排序方式.
            tag_id: MV 分类筛选.
        """
        param: dict[str, Any] = {"singermid": mid, "order": int(order), "count": num, "start": (page - 1) * num}
        if tag_id is not None:
            param["tagid"] = tag_id
        return CgiRequestData(
            param=param,
            pager_strategy=OffsetStrategy[SingerMvListResponse](
                offset_key="start",
                page_size_key="count",
                total_extractor=lambda r: r.total,
                count_extractor=lambda r: len(r.mv_list),
            ),
            items_extractor=lambda r: r.mv_list,
        )
