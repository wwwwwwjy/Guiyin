# SingerApi

::: modules.singer.SingerApi
