# AlbumApi

::: modules.album.AlbumApi
